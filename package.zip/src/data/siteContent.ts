export type Locale = "en" | "ml";

export interface HeroSlide {
  id: string;
  image: string;
  imageAlt: Record<Locale, string>;
  eyebrow: Record<Locale, string>;
  headline: Record<Locale, string[]>;
  description: Record<Locale, string>;
  primaryCta: Record<Locale, string>;
  primaryHref: string;
  secondaryCta: Record<Locale, string>;
  secondaryHref: string;
}

export interface ServiceItem {
  id: string;
  code: string;
  image: string;
  imageAlt: Record<Locale, string>;
  category: Record<Locale, string>;
  title: Record<Locale, string>;
  description: Record<Locale, string>;
  deliverables: Record<Locale, string[]>;
}

export interface TeamMember {
  id: string;
  isSampleProfile: boolean;
  image: string;
  imageAlt: Record<Locale, string>;
  name: Record<Locale, string>;
  designation: Record<Locale, string>;
  specialization: Record<Locale, string>;
  bio: Record<Locale, string>;
  linkedInUrl?: string;
}

/**
 * Editable Website Data
 * Note: Sample service descriptions, team profiles, and contact details are clearly marked
 * so they can be replaced with verified company records before launch.
 */
export const HERO_SLIDES: HeroSlide[] = [
  {
    id: "slide-01",
    image: "/images/hero-1.jpg",
    imageAlt: {
      en: "Sunlit international corporate headquarters atrium with travertine and deep petrol steel architecture",
      ml: "അന്താരാഷ്ട്ര കോർപ്പറേറ്റ് ആസ്ഥാനത്തിന്റെ മനോഹരമായ ആട്രിയം ദൃശ്യം",
    },
    eyebrow: {
      en: "INTEGRATED LEGAL & GLOBAL MOBILITY COUNSEL",
      ml: "സംയോജിത നിയമ-റീലൊക്കേഷൻ ഉപദേശക സേവനങ്ങൾ",
    },
    headline: {
      en: [
        "Navigating Cross-Border Law",
        "and Executive Relocation",
        "with Quiet Precision.",
      ],
      ml: [
        "അന്താരാഷ്ട്ര നിയമ-റീലൊക്കേഷൻ",
        "സേവനങ്ങളിൽ കൃത്യതയാർന്ന",
        "വിദഗ്ധ മാർഗ്ഗനിർദ്ദേശം.",
      ],
    },
    description: {
      en: "LRS unites corporate legal structuring, regulatory compliance, and end-to-end relocation management under one dedicated advisory practice.",
      ml: "കോർപ്പറേറ്റ് നിയമ നടപടികൾ, വിസ-ഇമിഗ്രേഷൻ അനുമതികൾ, എക്സിക്യൂട്ടീവ് റീലൊക്കേഷൻ സേവനങ്ങൾ എന്നിവ ഒരൊറ്റ മേൽക്കൂരയ്ക്ക് കീഴിൽ LRS ലഭ്യമാക്കുന്നു.",
    },
    primaryCta: {
      en: "Schedule a Consultation",
      ml: "കൺസൾട്ടേഷൻ ബുക്ക് ചെയ്യുക",
    },
    primaryHref: "#contact",
    secondaryCta: {
      en: "Explore Practice Areas",
      ml: "സേവനങ്ങൾ പരിചയപ്പെടുക",
    },
    secondaryHref: "#services",
  },
  {
    id: "slide-02",
    image: "/images/hero-2.jpg",
    imageAlt: {
      en: "Modern coastal residence at golden hour representing seamless executive relocation",
      ml: "എക്സിക്യൂട്ടീവ് റീലൊക്കേഷൻ പ്രതിനിധീകരിക്കുന്ന ആധുനിക വസതി",
    },
    eyebrow: {
      en: "BESPOKE DESTINATION & PRIVATE CLIENT SETTLING",
      ml: "വ്യക്തിഗത-കുടുംബ റീലൊക്കേഷൻ സഹായം",
    },
    headline: {
      en: [
        "Seamless Transitions for",
        "Global Executives, Families,",
        "and ReturningNRIs.",
      ],
      ml: [
        "ആഗോള എക്സിക്യൂട്ടീവുകൾക്കും",
        "കുടുംബങ്ങൾക്കും സുഗമമായ",
        "വാസസ്ഥല മാറ്റം.",
      ],
    },
    description: {
      en: "From visa clearances and residential lease structuring to school admissions and local registration, every relocation milestone is handled with discretion.",
      ml: "വിസ ക്ലിയറൻസ്, ഭവന വാടക കരാറുകൾ, തദ്ദേശ രജിസ്ട്രേഷൻ തുടങ്ങി പുതിയൊരു നാട്ടിലേക്ക് മാറുമ്പോഴുള്ള എല്ലാ ഘട്ടങ്ങളിലും പൂർണ്ണ പിന്തുണ.",
    },
    primaryCta: {
      en: "Explore Relocation Services",
      ml: "റീലൊക്കേഷൻ സേവനങ്ങൾ",
    },
    primaryHref: "#services",
    secondaryCta: {
      en: "About Our Practice",
      ml: "സ്ഥാപനത്തെക്കുറിച്ച്",
    },
    secondaryHref: "#about",
  },
  {
    id: "slide-03",
    image: "/images/hero-3.jpg",
    imageAlt: {
      en: "Refined contemporary legal advisory boardroom with warm walnut table and natural light",
      ml: "ആധുനിക ലീഗൽ അഡ്വൈസറി ബോർഡ്റൂം",
    },
    eyebrow: {
      en: "CORPORATE GOVERNANCE & REAL ESTATE DOCUMENTATION",
      ml: "കോർപ്പറേറ്റ് നിയമങ്ങളും വസ്തു ഇടപാട് രേഖകളും",
    },
    headline: {
      en: [
        "Diligent Legal Protection",
        "for Commercial Entities",
        "and Property Assets.",
      ],
      ml: [
        "വാണിജ്യ സ്ഥാപനങ്ങൾക്കും",
        "വസ്തു ഇടപാടുകൾക്കും",
        "ശക്തമായ നിയമ പരിരക്ഷ.",
      ],
    },
    description: {
      en: "Structured legal due diligence, contract drafting, and statutory compliance tailored for businesses establishing or expanding operations.",
      ml: "വ്യവസായ സംരംഭങ്ങൾക്കും വ്യക്തിഗത നിക്ഷേപങ്ങൾക്കും ആവശ്യമായ കരാറുകൾ, ഡ്യൂ ഡിലിജൻസ്, നിയമപരമായ അനുമതികൾ എന്നിവ കൃത്യതയോടെ നിർവഹിക്കുന്നു.",
    },
    primaryCta: {
      en: "Request Legal Advisory",
      ml: "നിയമോപദേശം തേടുക",
    },
    primaryHref: "#contact",
    secondaryCta: {
      en: "Meet the Advisory Team",
      ml: "ഉപദേശക സമിതി",
    },
    secondaryHref: "#team",
  },
];

export const SERVICES_DATA: ServiceItem[] = [
  {
    id: "service-immigration",
    code: "01",
    image: "/images/service-immigration.jpg",
    imageAlt: {
      en: "Bespoke dark teal leather legal portfolio and brass compass on travertine desk",
      ml: "നിയമ രേഖകളുടെ പോർട്ട്ഫോളിയോയും കോമ്പസും",
    },
    category: {
      en: "SAMPLE SERVICE • GLOBAL MOBILITY",
      ml: "മാതൃകാ സേവനം • ഗ്ലോബൽ മൊബിലിറ്റി",
    },
    title: {
      en: "Immigration, Visa & Consular Advisory",
      ml: "ഇമിഗ്രേഷൻ, വിസ & കോൺസുലാർ ഉപദേശം",
    },
    description: {
      en: "Sample service profile: End-to-end preparation of employment visas, business permits, FRRO registrations, and consular document legalization.",
      ml: "മാതൃകാ വിവരണം: തൊഴിൽ വിസകൾ, ബിസിനസ് പെർമിറ്റുകൾ, എഫ്.ആർ.ആർ.ഒ (FRRO) രജിസ്ട്രേഷൻ, കോൺസുലാർ സാക്ഷ്യപ്പെടുത്തലുകൾ എന്നിവയ്ക്കുള്ള സഹായം.",
    },
    deliverables: {
      en: ["Work Permit & Visa Filings", "FRRO & Residency Compliance", "Document Apostille & Attestation"],
      ml: ["വർക്ക് പെർമിറ്റ് & വിസ നടപടികൾ", "റസിഡൻസി രജിസ്ട്രേഷൻ", "രേഖകളുടെ സാക്ഷ്യപ്പെടുത്തൽ"],
    },
  },
  {
    id: "service-relocation",
    code: "02",
    image: "/images/service-relocation.jpg",
    imageAlt: {
      en: "Luxury contemporary courtyard residence with tranquil water and timber architecture",
      ml: "ആധുനിക രീതിയിലുള്ള മനോഹരമായ വസതി",
    },
    category: {
      en: "SAMPLE SERVICE • DESTINATION SETTLING",
      ml: "മാതൃകാ സേവനം • റീലൊക്കേഷൻ",
    },
    title: {
      en: "Executive & Family Relocation Management",
      ml: "എക്സിക്യൂട്ടീവ് & ഫാമിലി റീലൊക്കേഷൻ",
    },
    description: {
      en: "Sample service profile: Curated home search, neighborhood orientation, school search assistance, and settling-in coordination for relocating professionals.",
      ml: "മാതൃകാ വിവരണം: പുതിയ നഗരത്തിലേക്ക് മാറുന്ന ഉദ്യോഗസ്ഥർക്കും കുടുംബങ്ങൾക്കും അനുയോജ്യമായ വീട്, സ്കൂൾ പ്രവേശനം, പ്രാദേശിക സൗകര്യങ്ങൾ എന്നിവ ക്രമീകരിക്കുന്നു.",
    },
    deliverables: {
      en: ["Curated Home & Villa Search", "Schooling & Family Orientation", "Utility & Local Onboarding"],
      ml: ["അനുയോജ്യമായ വീട് കണ്ടെത്തൽ", "സ്കൂൾ പ്രവേശന സഹായം", "പ്രാദേശിക സൗകര്യങ്ങളുടെ ക്രമീകരണം"],
    },
  },
  {
    id: "service-corporate",
    code: "03",
    image: "/images/service-corporate.jpg",
    imageAlt: {
      en: "Architectural glass corporate tower reflecting deep petrol and azure sky",
      ml: "ആധുനിക കോർപ്പറേറ്റ് ഓഫീസ് സമുച്ചയം",
    },
    category: {
      en: "SAMPLE SERVICE • CORPORATE LAW",
      ml: "മാതൃകാ സേവനം • കോർപ്പറേറ്റ് നിയമം",
    },
    title: {
      en: "Corporate Structuring & Commercial Contracts",
      ml: "കോർപ്പറേറ്റ് രൂപീകരണവും വാണിജ്യ കരാറുകളും",
    },
    description: {
      en: "Sample service profile: Entity incorporation, joint venture agreements, commercial lease negotiations, and ongoing statutory governance.",
      ml: "മാതൃകാ വിവരണം: പുതിയ കമ്പനി രജിസ്ട്രേഷൻ, വാണിജ്യ കരാറുകൾ തയ്യാറാക്കൽ, സംയുക്ത സംരംഭങ്ങൾക്കുള്ള നിയമോപദേശം എന്നിവ നൽകുന്നു.",
    },
    deliverables: {
      en: ["Entity Incorporation & Filings", "Commercial Contract Drafting", "Regulatory Compliance Audits"],
      ml: ["കമ്പനി രജിസ്ട്രേഷൻ", "വാണിജ്യ കരാർ തയ്യാറാക്കൽ", "റെഗുലേറ്ററി കംപ്ലയൻസ് ഓഡിറ്റ്"],
    },
  },
  {
    id: "service-realestate",
    code: "04",
    image: "/images/service-realestate.jpg",
    imageAlt: {
      en: "Bright penthouse interior overlooking city skyline with travertine table",
      ml: "നഗരദൃശ്യമുള്ള ആധുനിക അപ്പാർട്ട്മെന്റ് ഇന്റീരിയർ",
    },
    category: {
      en: "SAMPLE SERVICE • PROPERTY & TENANCY",
      ml: "മാതൃകാ സേവനം • വസ്തു-വാടക നിയമങ്ങൾ",
    },
    title: {
      en: "Real Estate Due Diligence & Tenancy Law",
      ml: "വസ്തു ഇടപാട് പരിശോധനയും വാടക നിയമങ്ങളും",
    },
    description: {
      en: "Sample service profile: Title verification, residential and commercial lease structuring, NRI property management counsel, and registration support.",
      ml: "മാതൃകാ വിവരണം: വസ്തുക്കളുടെ ഉടമസ്ഥാവകാശ പരിശോധന, വാടക കരാറുകൾ, പ്രവാസികൾക്കുള്ള പ്രോപ്പർട്ടി ലീഗൽ സർവീസുകൾ എന്നിവ ലഭ്യമാക്കുന്നു.",
    },
    deliverables: {
      en: ["Title & Encumbrance Verification", "Executive Lease Structuring", "NRI Property Legal Counsel"],
      ml: ["ആധാര-ഉടമസ്ഥാവകാശ പരിശോധന", "എക്സിക്യൂട്ടീവ് ലീസ് കരാറുകൾ", "പ്രവാസി പ്രോപ്പർട്ടി നിയമോപദേശം"],
    },
  },
  {
    id: "service-customs",
    code: "05",
    image: "/images/about-editorial.jpg",
    imageAlt: {
      en: "Bespoke global consultancy gallery and reception space with deep teal glass partitions",
      ml: "ഗ്ലോബൽ കൺസൾട്ടൻസി ഓഫീസ് ഇന്റീരിയർ",
    },
    category: {
      en: "SAMPLE SERVICE • TRANSITION LOGISTICS",
      ml: "മാതൃകാ സേവനം • ട്രാൻസിഷൻ മാനേജ്മെന്റ്",
    },
    title: {
      en: "Cross-Border Mobility & Departure Support",
      ml: "അന്താരാഷ്ട്ര യാത്രാ-റീലൊക്കേഷൻ ഏകോപനം",
    },
    description: {
      en: "Sample service profile: Coordinated move management, customs documentation advisory, and lease exit or repatriation clearance.",
      ml: "മാതൃകാ വിവരണം: രാജ്യാന്തര താമസമാറ്റത്തിനാവശ്യമായ കസ്റ്റംസ് രേഖകൾ, ലീസ് ക്ലോഷർ, റീപാട്രിയേഷൻ ക്ലിയറൻസ് എന്നിവ ഏകോപിപ്പിക്കുന്നു.",
    },
    deliverables: {
      en: ["Customs Documentation Advisory", "Lease Surrender & Dilapidation", "Repatriation & Exit Clearances"],
      ml: ["കസ്റ്റംസ് ഡോക്യുമെന്റേഷൻ ഉപദേശം", "ലീസ് സറണ്ടർ നടപടികൾ", "എക്സിറ്റ് ക്ലിയറൻസ് സഹായം"],
    },
  },
];

export const TEAM_MEMBERS: TeamMember[] = [
  {
    id: "sample-member-1",
    isSampleProfile: true,
    image: "/images/team-1.jpg",
    imageAlt: {
      en: "Editorial portrait for sample Managing Partner profile",
      ml: "മാനേജിംഗ് പാർട്ണർ മാതൃകാ പ്രൊഫൈൽ ചിത്രം",
    },
    name: {
      en: "[Sample Profile] Adv. Arvind Menon",
      ml: "[മാതൃകാ പ്രൊഫൈൽ] അഡ്വ. അരവിന്ദ് മേനോൻ",
    },
    designation: {
      en: "Managing Partner — Corporate & Cross-Border Law",
      ml: "മാനേജിംഗ് പാർട്ണർ — കോർപ്പറേറ്റ് & ക്രോസ്-ബോർഡർ ലോ",
    },
    specialization: {
      en: "Replace with actual partner biography in src/data/siteContent.ts",
      ml: "യഥാർത്ഥ വിവരങ്ങൾ src/data/siteContent.ts ഫയലിൽ ചേർക്കുക",
    },
    bio: {
      en: "Sample placeholder profile illustrating layout and typography for senior legal leadership focusing on corporate structuring and international regulatory compliance.",
      ml: "കോർപ്പറേറ്റ് നിയമങ്ങളിലും അന്താരാഷ്ട്ര റെഗുലേറ്ററി നടപടികളിലും നേതൃത്വം നൽകുന്ന സീനിയർ പാർട്ണറുടെ വിവരങ്ങൾ ചേർക്കുന്നതിനുള്ള മാതൃകാ കാർഡ്.",
    },
  },
  {
    id: "sample-member-2",
    isSampleProfile: true,
    image: "/images/team-2.jpg",
    imageAlt: {
      en: "Editorial portrait for sample Director of Relocation Services profile",
      ml: "ഗ്ലോബൽ മൊബിലിറ്റി ഡയറക്ടർ മാതൃകാ ചിത്രം",
    },
    name: {
      en: "[Sample Profile] Elena Rostova",
      ml: "[മാതൃകാ പ്രൊഫൈൽ] എലേന റോസ്റ്റോവ",
    },
    designation: {
      en: "Director — Global Mobility & Executive Relocation",
      ml: "ഡയറക്ടർ — ഗ്ലോബൽ മൊബിലിറ്റി & എക്സിക്യൂട്ടീവ് റീലൊക്കേഷൻ",
    },
    specialization: {
      en: "Replace with actual director biography in src/data/siteContent.ts",
      ml: "യഥാർത്ഥ വിവരങ്ങൾ src/data/siteContent.ts ഫയലിൽ ചേർക്കുക",
    },
    bio: {
      en: "Sample placeholder profile demonstrating how executive destination services, diplomatic transitions, and family settling-in leads are presented.",
      ml: "എക്സിക്യൂട്ടീവ് റീലൊക്കേഷൻ, ഡിപ്ലോമാറ്റിക് ട്രാൻസിഷൻ, ഫാമിലി സെറ്റിലിംഗ് വിഭാഗം മേധാവിയുടെ വിവരങ്ങൾ നൽകാനുള്ള മാതൃകാ പ്രൊഫൈൽ.",
    },
  },
  {
    id: "sample-member-3",
    isSampleProfile: true,
    image: "/images/team-3.jpg",
    imageAlt: {
      en: "Editorial portrait for sample Principal Counsel profile",
      ml: "പ്രിൻസിപ്പൽ കൗൺസൽ മാതൃകാ പ്രൊഫൈൽ ചിത്രം",
    },
    name: {
      en: "[Sample Profile] Adv. Clara Vance",
      ml: "[മാതൃകാ പ്രൊഫൈൽ] അഡ്വ. ക്ലാര വാൻസ്",
    },
    designation: {
      en: "Principal Counsel — Real Estate & Private Client Practice",
      ml: "പ്രിൻസിപ്പൽ കൗൺസൽ — റിയൽ എസ്റ്റേറ്റ് & പ്രൈവറ്റ് ക്ലയന്റ്സ്",
    },
    specialization: {
      en: "Replace with actual counsel biography in src/data/siteContent.ts",
      ml: "യഥാർത്ഥ വിവരങ്ങൾ src/data/siteContent.ts ഫയലിൽ ചേർക്കുക",
    },
    bio: {
      en: "Sample placeholder profile showcasing property due diligence, commercial tenancy structuring, and cross-border private client advisory.",
      ml: "വസ്തു ഇടപാട് നിയമങ്ങൾ, വാടക കരാറുകൾ, പ്രൈവറ്റ് ക്ലയന്റ് ഉപദേശം എന്നിവ കൈകാര്യം ചെയ്യുന്ന ലീഗൽ കൗൺസലിന്റെ മാതൃകാ പ്രൊഫൈൽ.",
    },
  },
  {
    id: "sample-member-4",
    isSampleProfile: true,
    image: "/images/team-3.jpg",
    imageAlt: {
      en: "Editorial portrait for sample Principal Counsel profile",
      ml: "പ്രിൻസിപ്പൽ കൗൺസൽ മാതൃകാ പ്രൊഫൈൽ ചിത്രം",
    },
    name: {
      en: "[Sample Profile] Adv. Clara Vance",
      ml: "[മാതൃകാ പ്രൊഫൈൽ] അഡ്വ. ക്ലാര വാൻസ്",
    },
    designation: {
      en: "Principal Counsel — Real Estate & Private Client Practice",
      ml: "പ്രിൻസിപ്പൽ കൗൺസൽ — റിയൽ എസ്റ്റേറ്റ് & പ്രൈവറ്റ് ക്ലയന്റ്സ്",
    },
    specialization: {
      en: "Replace with actual counsel biography in src/data/siteContent.ts",
      ml: "യഥാർത്ഥ വിവരങ്ങൾ src/data/siteContent.ts ഫയലിൽ ചേർക്കുക",
    },
    bio: {
      en: "Sample placeholder profile showcasing property due diligence, commercial tenancy structuring, and cross-border private client advisory.",
      ml: "വസ്തു ഇടപാട് നിയമങ്ങൾ, വാടക കരാറുകൾ, പ്രൈവറ്റ് ക്ലയന്റ് ഉപദേശം എന്നിവ കൈകാര്യം ചെയ്യുന്ന ലീഗൽ കൗൺസലിന്റെ മാതൃകാ പ്രൊഫൈൽ.",
    },
  },
];
