import { Locale } from "./siteContent";

export interface TranslationDictionary {
  meta: {
    languageLabel: string;
    translationReviewNotice: string;
  };
  nav: {
    home: string;
    about: string;
    services: string;
    team: string;
    contact: string;
    inquireCta: string;
    languageSelectorLabel: string;
    openMenuLabel: string;
    closeMenuLabel: string;
  };
  hero: {
    prevSlideLabel: string;
    nextSlideLabel: string;
    pauseAutoplayLabel: string;
    resumeAutoplayLabel: string;
    scrollIndicator: string;
  };
  about: {
    sectionLabel: string;
    headline: string;
    leadParagraph: string;
    bodyParagraph: string;
    placeholderNotice: string;
    pillars: {
      title: string;
      description: string;
    }[];
    imageCaptionTitle: string;
    imageCaptionSubtitle: string;
    ctaLabel: string;
  };
  services: {
    sectionLabel: string;
    headline: string;
    description: string;
    sampleNotice: string;
    exploreLink: string;
    viewAllCta: string;
    prevLabel: string;
    nextLabel: string;
  };
  team: {
    sectionLabel: string;
    headline: string;
    description: string;
    sampleBadge: string;
    sampleDisclaimer: string;
  };
  contact: {
    sectionLabel: string;
    headline: string;
    description: string;
    formTitle: string;
    nameLabel: string;
    namePlaceholder: string;
    emailLabel: string;
    emailPlaceholder: string;
    serviceLabel: string;
    serviceOptions: string[];
    messageLabel: string;
    messagePlaceholder: string;
    submitButton: string;
    successMessage: string;
    placeholderContactNotice: string;
    officeLabel: string;
    officeValue: string;
    emailTitle: string;
    emailValue: string;
    phoneTitle: string;
    phoneValue: string;
    hoursTitle: string;
    hoursValue: string;
  };
  footer: {
    brandStatement: string;
    navigationHeading: string;
    practiceHeading: string;
    contactHeading: string;
    placeholderBadge: string;
    copyright: string;
    privacyPolicy: string;
    termsOfEngagement: string;
    disclaimer: string;
  };
}

export const TRANSLATIONS: Record<Locale, TranslationDictionary> = {
  en: {
    meta: {
      languageLabel: "English",
      translationReviewNotice:
        "Bilingual Content Mode Active — Sample copy & translations marked for business review.",
    },
    nav: {
      home: "Home",
      about: "About",
      services: "Services",
      team: "Leadership",
      contact: "Contact",
      inquireCta: "Client Inquiry",
      languageSelectorLabel: "Select Website Language",
      openMenuLabel: "Open navigation menu",
      closeMenuLabel: "Close navigation menu",
    },
    hero: {
      prevSlideLabel: "Previous slide",
      nextSlideLabel: "Next slide",
      pauseAutoplayLabel: "Pause slider autoplay",
      resumeAutoplayLabel: "Resume slider autoplay",
      scrollIndicator: "Scroll to explore",
    },
    about: {
      sectionLabel: "01 / ABOUT LRS",
      headline: "Where Legal Rigor Meets Effortless Global Relocation.",
      leadParagraph:
        "LRS (Legal & Relocation Services) is an integrated advisory practice built around a singular premise: cross-border mobility and commercial expansion require synchronized legal protection and on-the-ground relocation stewardship.",
      bodyParagraph:
        "Whether advising a multinational enterprise on corporate structuring and work permits, or guiding an executive family through property acquisition, tenancy contracts, and destination settling, our methodology prioritizes clarity, statutory compliance, and personal discretion.",
      placeholderNotice:
        "Editorial Placeholder Overview — Ready to be customized with your firm's founding history, jurisdictional registrations, and verified client milestones.",
      pillars: [
        {
          title: "Single-Point Accountability",
          description:
            "Legal counsel and relocation specialists collaborate within one unified workflow, eliminating fragmented vendor handoffs.",
        },
        {
          title: "Statutory & Consular Precision",
          description:
            "Every visa petition, lease deed, and corporate filing is vetted against current national and regional regulatory frameworks.",
        },
        {
          title: "Discreet Private Client Care",
          description:
            "Tailored destination orientation, residential search, and administrative onboarding designed for executives and returning NRIs.",
        },
      ],
      imageCaptionTitle: "LRS Advisory Practice",
      imageCaptionSubtitle: "Corporate Legal Counsel & Destination Mobility",
      ctaLabel: "Discuss Your Mandate",
    },
    services: {
      sectionLabel: "02 / PRACTICE AREAS & MOBILITY SERVICES",
      headline: "Integrated Capabilities Across Law & Relocation.",
      description:
        "Explore our core advisory pillars. Each practice area below is structured as editable sample content in src/data/siteContent.ts so your exact service scope can be updated effortlessly.",
      sampleNotice: "Editable Sample Practice Areas — Autoplay Loop Enabled",
      exploreLink: "Inquire About Service",
      viewAllCta: "Request a Tailored Scope of Work",
      prevLabel: "Previous service card",
      nextLabel: "Next service card",
    },
    team: {
      sectionLabel: "03 / ADVISORY LEADERSHIP",
      headline: "Guided by Seasoned Legal & Mobility Specialists.",
      description:
        "Our multidisciplinary structure pairs legal advocates with dedicated relocation consultants.",
      sampleBadge: "SAMPLE PROFILE — REPLACE IN DATA FILE",
      sampleDisclaimer:
        "Note: The profiles below are clearly marked sample placeholders stored in src/data/siteContent.ts to demonstrate card layout, typography, and hover interactions without fabricating personnel.",
    },
    contact: {
      sectionLabel: "04 / INITIATE AN INQUIRY",
      headline: "Begin a Confidential Conversation with LRS.",
      description:
        "Share your legal or relocation requirements below. Contact coordinates are marked as editable placeholders until your official office details are inserted.",
      formTitle: "Direct Advisory Inquiry",
      nameLabel: "Full Name / Organization",
      namePlaceholder: "e.g., Arjun Nair / Horizon Global Ltd.",
      emailLabel: "Work or Personal Email",
      emailPlaceholder: "name@organization.com",
      serviceLabel: "Primary Area of Interest",
      serviceOptions: [
        "Corporate Legal & Entity Structuring",
        "Immigration, Visa & FRRO Advisory",
        "Executive & Family Relocation",
        "Real Estate Due Diligence & Tenancy",
        "Combined Legal & Relocation Mandate",
      ],
      messageLabel: "Brief Outline of Requirements",
      messagePlaceholder:
        "Please describe your timeline, jurisdiction, or relocation destination...",
      submitButton: "Submit Confidential Inquiry",
      successMessage:
        "Thank you. Your inquiry has been recorded in this interactive preview. In production, wire this handler to your preferred email or CRM endpoint.",
      placeholderContactNotice: "SAMPLE CONTACT PLACEHOLDERS — EDIT IN TRANSLATIONS.TS",
      officeLabel: "Principal Advisory Office (Placeholder)",
      officeValue: "[Placeholder: Insert Suite, Building, Kochi / Global Office Address]",
      emailTitle: "Advisory Desk Email (Placeholder)",
      emailValue: "contact@lrs-example.com (Placeholder)",
      phoneTitle: "Direct Consultation Line (Placeholder)",
      phoneValue: "+91 (000) 000-0000 (Placeholder)",
      hoursTitle: "Consultation Hours",
      hoursValue: "Monday – Friday, 09:00 – 18:30 IST",
    },
    footer: {
      brandStatement:
        "LRS — Legal & Relocation Services delivers cohesive legal counsel, regulatory compliance, and bespoke destination management for businesses and private clients.",
      navigationHeading: "Navigation",
      practiceHeading: "Core Practice Areas",
      contactHeading: "Contact Coordinates (Placeholders)",
      placeholderBadge: "Sample Contact Info — Replace Before Launch",
      copyright: `© ${new Date().getFullYear()} LRS Legal & Relocation Services. All rights reserved.`,
      privacyPolicy: "Privacy Policy",
      termsOfEngagement: "Terms of Engagement",
      disclaimer:
        "Attorney & Advisory Notice: Website content is for informational purposes and does not constitute a formal attorney-client relationship until an engagement letter is executed.",
    },
  },
  ml: {
    meta: {
      languageLabel: "മലയാളം",
      translationReviewNotice:
        "മലയാളം ഭാഷാ ക്രമീകരണം സജീവമാണ് — പ്രസിദ്ധീകരിക്കുന്നതിന് മുമ്പ് വിവർത്തനങ്ങൾ പരിശോധിച്ച് ഉറപ്പുവരുത്തുക.",
    },
    nav: {
      home: "ഹോം",
      about: "ഞങ്ങളെക്കുറിച്ച്",
      services: "സേവനങ്ങൾ",
      team: "നേതൃത്വം",
      contact: "ബന്ധപ്പെടുക",
      inquireCta: "കൺസൾട്ടേഷൻ",
      languageSelectorLabel: "ഭാഷ തിരഞ്ഞെടുക്കുക",
      openMenuLabel: "നാവിഗേഷൻ മെനു തുറക്കുക",
      closeMenuLabel: "നാവിഗേഷൻ മെനു അടയ്ക്കുക",
    },
    hero: {
      prevSlideLabel: "മുമ്പത്തെ സ്ലൈഡ്",
      nextSlideLabel: "അടുത്ത സ്ലൈഡ്",
      pauseAutoplayLabel: "സ്ലൈഡർ താൽക്കാലികമായി നിർത്തുക",
      resumeAutoplayLabel: "സ്ലൈഡർ പുനരാരംഭിക്കുക",
      scrollIndicator: "താഴേക്ക് സ്ക്രോൾ ചെയ്യുക",
    },
    about: {
      sectionLabel: "01 / LRS-നെ പരിചയപ്പെടാം",
      headline: "നിയമപരമായ കൃത്യതയും സുഗമമായ റീലൊക്കേഷൻ സേവനങ്ങളും ഒരൊറ്റ കുടക്കീഴിൽ.",
      leadParagraph:
        "അന്താരാഷ്ട്ര തലത്തിലുള്ള ബിസിനസ് വിപുലീകരണത്തിനും താമസമാറ്റത്തിനും കൃത്യമായ നിയമസഹായവും പ്രായോഗിക റീലൊക്കേഷൻ പിന്തുണയും ഒരേസമയം ആവശ്യമാണ് എന്ന കാഴ്ചപ്പാടിലാണ് LRS (Legal & Relocation Services) പ്രവർത്തിക്കുന്നത്.",
      bodyParagraph:
        "കോർപ്പറേറ്റ് സ്ഥാപനങ്ങളുടെ രജിസ്ട്രേഷൻ, വിസ-ഇമിഗ്രേഷൻ അനുമതികൾ എന്നിവ മുതൽ എക്സിക്യൂട്ടീവുകൾക്കും പ്രവാസി കുടുംബങ്ങൾക്കും ആവശ്യമായ വസ്തു ഇടപാട് പരിശോധന, വാടക കരാറുകൾ, പുതിയ നാട്ടിലെ താമസ സൗകര്യങ്ങൾ എന്നിവ വരെ വ്യക്തതയോടെയും വിശ്വാസ്യതയോടെയും ഞങ്ങൾ നിർവഹിക്കുന്നു.",
      placeholderNotice:
        "മാതൃകാ വിവരണം (Editorial Placeholder) — നിങ്ങളുടെ സ്ഥാപനത്തിന്റെ യഥാർത്ഥ ചരിത്രവും വിവരങ്ങളും ഇവിടെ എളുപ്പത്തിൽ ചേർക്കാവുന്നതാണ്.",
      pillars: [
        {
          title: "ഏകീകൃത സേവന ശൈലി",
          description:
            "നിയമ വിദഗ്ധരും റീലൊക്കേഷൻ കൺസൾട്ടന്റുമാരും ഒരേ ടീമായി പ്രവർത്തിക്കുന്നതിനാൽ നടപടിക്രമങ്ങൾ വേഗത്തിലും ലളിതമായും പൂർത്തിയാകുന്നു.",
        },
        {
          title: "നിയമ-കോൺസുലാർ കൃത്യത",
          description:
            "വിസ അപേക്ഷകൾ, വാടക-വസ്തു കരാറുകൾ, കമ്പനി രേഖകൾ എന്നിവയെല്ലാം നിലവിലെ നിയമ മാനദണ്ഡങ്ങൾക്കനുസൃതമായി സൂക്ഷ്മമായി തയ്യാറാക്കുന്നു.",
        },
        {
          title: "വ്യക്തിഗത ശ്രദ്ധയും സ്വകാര്യതയും",
          description:
            "എക്സിക്യൂട്ടീവുകൾക്കും നാട്ടിലേക്ക് തിരിച്ചെത്തുന്ന പ്രവാസികൾക്കും (NRIs) അനുയോജ്യമായ വീട്, സ്കൂൾ, മറ്റ് പ്രാദേശിക രജിസ്ട്രേഷനുകൾ എന്നിവയിൽ പൂർണ്ണ പിന്തുണ.",
        },
      ],
      imageCaptionTitle: "LRS അഡ്വൈസറി പ്രാക്ടീസ്",
      imageCaptionSubtitle: "ലീഗൽ കൗൺസൽ & ഗ്ലോബൽ മൊബിലിറ്റി",
      ctaLabel: "സേവനങ്ങളെക്കുറിച്ച് സംസാരിക്കാം",
    },
    services: {
      sectionLabel: "02 / പ്രധാന സേവന മേഖലകൾ",
      headline: "നിയമ-റീലൊക്കേഷൻ രംഗത്തെ സമഗ്ര സേവനങ്ങൾ.",
      description:
        "ഞങ്ങളുടെ പ്രധാന സേവന മേഖലകൾ താഴെ നൽകുന്നു. ഇവയെല്ലാം src/data/siteContent.ts എന്ന ഫയലിൽ എഡിറ്റ് ചെയ്യാവുന്ന മാതൃകാ വിവരങ്ങളായി (Sample Content) ക്രമീകരിച്ചിരിക്കുന്നു.",
      sampleNotice: "എഡിറ്റ് ചെയ്യാവുന്ന മാതൃകാ സേവനങ്ങൾ • ഓട്ടോപ്ലേ കറൗസൽ",
      exploreLink: "കൂടുതൽ അറിയുക",
      viewAllCta: "പ്രത്യേക സേവന പാക്കേജ് ആവശ്യപ്പെടുക",
      prevLabel: "മുമ്പത്തെ സേവനം",
      nextLabel: "അടുത്ത സേവനം",
    },
    team: {
      sectionLabel: "03 / ഉപദേശക സമിതി",
      headline: "പരിചയസമ്പന്നരായ നിയമ-റീലൊക്കേഷൻ വിദഗ്ധർ.",
      description:
        "നിയമ രംഗത്തെയും അന്താരാഷ്ട്ര റീലൊക്കേഷൻ മേഖലയിലെയും വിദഗ്ധരുടെ കൂട്ടായ്മ.",
      sampleBadge: "മാതൃകാ പ്രൊഫൈൽ — ഡാറ്റാ ഫയലിൽ മാറ്റം വരുത്താം",
      sampleDisclaimer:
        "ശ്രദ്ധിക്കുക: യഥാർത്ഥ വ്യക്തികളുടെ വിവരങ്ങൾ ചേർക്കുന്നതുവരെ ഡിസൈൻ വ്യക്തമാക്കുന്നതിനായി നൽകിയിട്ടുള്ള മാതൃകാ പ്രൊഫൈലുകളാണ് (Sample Placeholders) താഴെ കാണുന്നത്.",
    },
    contact: {
      sectionLabel: "04 / ഞങ്ങളുമായി ബന്ധപ്പെടുക",
      headline: "നിങ്ങളുടെ ആവശ്യങ്ങൾ LRS ടീമുമായി പങ്കുവെക്കുക.",
      description:
        "നിയമപരമോ റീലൊക്കേഷൻ സംബന്ധമായതോ ആയ ആവശ്യങ്ങൾ താഴെ രേഖപ്പെടുത്താം. സ്ഥാപനത്തിന്റെ ഔദ്യോഗിക വിലാസവും ഫോൺ നമ്പറും ചേർക്കുന്നതുവരെ മാതൃകാ വിവരങ്ങളാണ് നൽകിയിരിക്കുന്നത്.",
      formTitle: "കൺസൾട്ടേഷൻ അപേക്ഷ",
      nameLabel: "പേര് / സ്ഥാപനം",
      namePlaceholder: "ഉദാ: അർജുൻ നായർ / ഹൊറൈസൺ ഗ്ലോബൽ",
      emailLabel: "ഇമെയിൽ വിലാസം",
      emailPlaceholder: "name@organization.com",
      serviceLabel: "ആവശ്യമായ സേവന വിഭാഗം",
      serviceOptions: [
        "കോർപ്പറേറ്റ് നിയമം & കമ്പനി രൂപീകരണം",
        "ഇമിഗ്രേഷൻ, വിസ & FRRO സേവനങ്ങൾ",
        "എക്സിക്യൂട്ടീവ് & ഫാമിലി റീലൊക്കേഷൻ",
        "വസ്തു ഇടപാട് പരിശോധന & വാടക കരാറുകൾ",
        "സംയോജിത നിയമ-റീലൊക്കേഷൻ പാക്കേജ്",
      ],
      messageLabel: "ആവശ്യങ്ങളുടെ ലഘു വിവരണം",
      messagePlaceholder:
        "നിങ്ങളുടെ സമയക്രമം, സ്ഥലം അല്ലെങ്കിൽ ആവശ്യമായ സേവനങ്ങളെക്കുറിച്ച് ചുരുക്കത്തിൽ എഴുതുക...",
      submitButton: "അപേക്ഷ സമർപ്പിക്കുക",
      successMessage:
        "നന്ദി! നിങ്ങളുടെ സന്ദേശം ഈ പ്രിവ്യൂവിൽ രേഖപ്പെടുത്തിയിട്ടുണ്ട്. പ്രൊഡക്ഷൻ സൈറ്റിൽ ഇത് നിങ്ങളുടെ ഇമെയിൽ അല്ലെങ്കിൽ സി.ആർ.എം (CRM) സിസ്റ്റവുമായി ബന്ധിപ്പിക്കാവുന്നതാണ്.",
      placeholderContactNotice: "മാതൃകാ വിലാസ വിവരങ്ങൾ — TRANSLATIONS.TS-ൽ മാറ്റാം",
      officeLabel: "പ്രധാന ഓഫീസ് വിലാസം (Placeholder)",
      officeValue: "[വിലാസം ചേർക്കുക: കൊച്ചി / ഗ്ലോബൽ ഓഫീസ് വിലാസം]",
      emailTitle: "ഇമെയിൽ (Placeholder)",
      emailValue: "contact@lrs-example.com (Placeholder)",
      phoneTitle: "ഫോൺ നമ്പർ (Placeholder)",
      phoneValue: "+91 (000) 000-0000 (Placeholder)",
      hoursTitle: "പ്രവർത്തന സമയം",
      hoursValue: "തിങ്കൾ – വെള്ളി, രാവിലെ 09:00 – വൈകുന്നേരം 06:30 IST",
    },
    footer: {
      brandStatement:
        "വാണിജ്യ സ്ഥാപനങ്ങൾക്കും വ്യക്തികൾക്കും വിശ്വസനീയമായ നിയമോപദേശവും അന്താരാഷ്ട്ര നിലവാരത്തിലുള്ള റീലൊക്കേഷൻ സേവനങ്ങളും LRS (Legal & Relocation Services) ഉറപ്പാക്കുന്നു.",
      navigationHeading: "പ്രധാന പേജുകൾ",
      practiceHeading: "സേവന മേഖലകൾ",
      contactHeading: "വിലാസം (Placeholders)",
      placeholderBadge: "മാതൃകാ വിവരങ്ങൾ — ലോഞ്ചിന് മുമ്പ് മാറ്റുക",
      copyright: `© ${new Date().getFullYear()} LRS Legal & Relocation Services. എല്ലാ അവകാശങ്ങളും നിക്ഷിപ്തം.`,
      privacyPolicy: "സ്വകാര്യതാ നയം",
      termsOfEngagement: "സേവന നിബന്ധനകൾ",
      disclaimer:
        "നിയമപരമായ അറിയിപ്പ്: ഈ വെബ്സൈറ്റിലെ വിവരങ്ങൾ പൊതുവായ അറിവിലേക്കുള്ളതാണ്. ഔദ്യോഗിക കരാറിൽ ഏർപ്പെടുന്നതുവരെ ഇത് ഒരു അറ്റോർണി-ക്ലയന്റ് ബന്ധമായി കണക്കാക്കുന്നതല്ല.",
    },
  },
};
